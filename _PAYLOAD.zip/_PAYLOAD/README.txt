HELLO. This is the readme for Kasia Molga's GROW project. 

Content forthcoming. :)